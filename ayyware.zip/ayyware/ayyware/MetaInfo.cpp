/*
Syn's AYYWAREFramework
*/
#include "Utilities.h"

#define AimWare_META_GAME "Counter-Strike: Global Offensive"

void PrintMetaHeader()
{
	printf("                                  Ayy");
	Utilities::SetConsoleColor(FOREGROUND_INTENSE_GREEN);
	printf("Ware\n");
	Utilities::SetConsoleColor(FOREGROUND_WHITE);
	Utilities::Log("Build %s", __DATE__);
	Utilities::Log("Setting Up AYYWAREfor %s", AimWare_META_GAME);
}